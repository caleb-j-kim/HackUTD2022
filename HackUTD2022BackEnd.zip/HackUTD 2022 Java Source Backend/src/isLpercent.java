
public class isLpercent {

}

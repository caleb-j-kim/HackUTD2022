import java.text.DecimalFormat; //used to format the doubles when doing calculations

class HackUTD2022Backend {

	//imported integers and doubles from the front end aka Farman
	
	private double monthlyBudget; 
	private double totalBills; 
	private int percentSaved; 
	private int totalGallons; 
	private int gasTrips;
	
	// user responses converted to character data types
	
	private String q3;
	private String q4;
	private String q5;
	
	//local variables used by the front end to print the total budgets
	
	private double groceriesBudget = 0.0;
	private double totalGas = 0.0; //used to find the total amount spent on gas per month
	private double recreationBudget = 0.0;
	private double finalBudget = 0.0;
	private final double gasPrice = 2.99; 
	
	//local variables that represent the percentages of each category aside from saving
	
	private int groceryPercent = 0;
	private int recreationPercent = 0; //includes prices of subscriptions
	private int gasPercent = 0; //totalGas / monthlyBudget rounded to the nearest whole number
	private int billsPercent = 0;
	private int spendingPercentage = 0;
	private int sumPercent = 0;
	//also return the saving percentage
	
	private String error = "";

	//new variables that's information from the front end that will be transfered to back end
	

	double mB, tB;
	int pS, tG, gT;
	String qt3, qt4, qt5;
	String t1, t2, t6, t7, t8; //t stands for temp and was originally int and doubles
    
	/* methods to determine the total amount of money that can be spent per category
	 * after getting the user inputed answers and turn the answers into percentages
	 * with the percents, calculate the budget per each category
	 * format the doubles and return the strings that state what how much the user can
	 * spend on each category and then return the formatted doubles after all the strings
	 * (doubles are used for the pi chart graph)
	 * (before returning the recreational budget, subtract the subscriptions from the 
	 * original recreational budget and state "after paying for subscriptions")
	 * */
    
    /* method that uses transfers information from front end to the back end */
    
    public void fileTransfer() {
    	
    	/* double mB for front end monthlyBudget
    	 * double tB for front end totalBills
    	 * int pS for front end percentSaved
    	 * int tG for front end totalGallons
    	 * int gT for front end gasTrips
    	 * qt3 for front end q3
    	 * qt4 for front end q4
    	 * qt5 for front end q5
    	 * */
    }
    
    /* constructors */
    
    public HackUTD2022Backend () { //default constructor
    	
    	monthlyBudget = 0.0;
    	totalBills = 0.0;
    	percentSaved = 0;
    	totalGallons = 0;
    	gasTrips = 0;
    	q3 = "";
    	q4 = "";
    	q5 = "";

    }
    
    // mutator methods that sets the variables to their updated values
    
    public void setMonthBud() {
    	
    	mB = Double.parseDouble(t1);
    	monthlyBudget = mB;
    }
    
    public void setTotalBills() {
    	
    	tB = Double.parseDouble(t6);
    	totalBills = tB;
    }
    
    public void setSaved() {
    	
    	q3 = qt3;
    	pS = Integer.parseInt(q3);
    	percentSaved = pS;
    	percentSaved = pS;
    }
    
    public void setTotalGallons() {
    	
    	tG = Integer.parseInt(t8);
    	totalGallons = tG;
    }
    
    public void setTrips() {
    	
    	gT = Integer.parseInt(t7);
    	gasTrips = gT;
    }
    
    public void transformQ4() {
    	
    	q4 = qt4;
    	int gP = Integer.parseInt(q4);
    	groceryPercent = gP; //gP = grocery Percentage
    }
    
    public void transformQ5() {
    	
    	q5 = qt5;
    	int rP = Integer.parseInt(q5); //rP = recreation Percentage
    	recreationPercent = rP;
    }
    
    /* method that finds how much of the budget is allocated to spending */
        
    public int calculateSpending() {
    	
    	spendingPercentage = 100 - percentSaved;
    	return spendingPercentage;
    }
    
    /* method that calculates the gas price and percent */
    
    public int gasCalculations() {
    	
    	totalGas = gasTrips * (gasPrice * totalGallons);
    	double rawGasPercent = totalGas / (spendingPercentage * monthlyBudget);
    	gasPercent = (int) Math.round(rawGasPercent); //casts to int
    	return gasPercent;
    }
    
    public int calcBillsPercent() {
    	
    	double ogBillPercentage = (totalBills / spendingPercentage) * 100; 
    	int finalBillPercentage = (int) Math.round(ogBillPercentage);
    	return finalBillPercentage; 
    }
    
	/* method that calculates all of the percentages and sees if the sum of the percentages
	over 100% */
    
    public int sumPercents() {
    	
    	sumPercent = (gasPercent + recreationPercent + groceryPercent);
    	
    	return sumPercent;
    }
    
    /* method that stops the program if the sum of the percentages are too high */
    
    public String testPercentages() {
    	
    	error = "";
    	
    	if (sumPercent > 100) {
    		
    	error = ("The sum of the percentages is over 100%. Please reevaluate your"
    				+ " responses");

    	}

    	else {
    		
    		finalBudget = spendingPercentage * monthlyBudget; 
    	}
    	
		return error;
    }
    
    public void stop() { 
    	
    	if (error != "") {
    		
    		System.exit(0); //terminates program
    	}
    }
    

    
    /* methods that use the percentages to calculate how much money the user
     * can spend on every category */
    
    public double calcGrocery() {
    	
    	double finalGroceryPercent = 0.0;
    		finalGroceryPercent = groceryPercent * spendingPercentage;
    		groceriesBudget = finalGroceryPercent * finalBudget;   	
    	DecimalFormat d = new DecimalFormat("####.##");
    	double fGroceriesBudget;
    	String temp;
    	temp = d.format(groceriesBudget); //format method converts double to string
    	fGroceriesBudget = Double.parseDouble(temp);
    	
    	return fGroceriesBudget; 
    }
    
    public double calcRecreation() {
    	
    	double finalRecreationPercent = 0.0;
    		finalRecreationPercent = recreationPercent * spendingPercentage;
    		recreationBudget = finalRecreationPercent * finalBudget;    	
    	DecimalFormat d = new DecimalFormat("####.##");
    	double fRecreationBudget;
    	String temp;
    	temp = d.format(recreationBudget);
    	fRecreationBudget = Double.parseDouble(temp);
    	
    	return fRecreationBudget;
    }
    
    /* toString methods that state the total amount of money that can be spent*/
    
    public String toGas() {
    	
    	int finalGas;
    	finalGas = (int) Math.round(gasPercent * totalGas);
    	String temp;
    	temp = "The budget for gas is " + finalGas;
    	
    	return temp;
    }
    
    public String toGroceries() {
    	
    	String temp;
    	temp = "The budget for groceries is " + calcGrocery();
    	return temp;
    }
    
    public String toRecreation() {
    	
    	String temp;
    	temp = "The budget for groceries is " + calcRecreation();
    	return temp;
    }
    
    public String toBills() {
    	
    	String temp;
    	temp = ("The budget for bills is " + totalBills + " (" + 
    	calcBillsPercent() + "% of the budget");
    	return temp;
    }
    
    /* method will export strings, ints, and doubles back to the front end */
}